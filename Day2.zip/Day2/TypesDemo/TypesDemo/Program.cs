﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


/*
 * Types in C#:
 * Value Types: stored in stack
 *          Primitive (Singular-single value) data types except string
 *          ex. int, float, struct, char, enum, bool
 *          
 *  Reference Types: stored in heap
 *          Non Primitive (Complex value - more than one value)
 *          Refer by memory address
 *          ex. String, class, interface, arrays
 */


namespace TypesDemo
{
    class Employee
    {
        public int id;
        public string name;
    }

    class Program
    {
        static void Main(string[] args)
        {
            //Value Type
            int i = 100;
            Console.WriteLine("Before calling Method: " + i);
            PassByValue(ref i); // reference type
           // PassByValue(i); // value type
            Console.WriteLine("After calling Method: " + i);

            //Ref Type

            //Employee emp = new Employee();  //one type of instatiating
            //emp.id = 1;
            //emp.name = "Pranav";

            //Employee emp1 = new Employee() { id = 2, name = "Sonu" };   //other type of instatiating
            //Console.WriteLine("Before calling method: "+emp1.id+" "+emp1.name);

            //PassByRef(emp1);
            //Console.WriteLine("After calling method: " + emp1.id + " " + emp1.name);

            Console.ReadLine();
        }

        ////whenever we pass value type to method a copy of that type is passed, not an actual value
        //static void PassByValue(int inum)
        //{
        //    inum = 200;
        //}

        //whenever we pass reference type a memory address is passed
        static void PassByRef(Employee emp)
        {
            emp.name = "abc";
            emp.id = 125;
        }

        //using ref keyword we can have passbyvalue act as a reference type
        static void PassByValue(ref int inum)
        {
            inum = 200;
        }







    }
}
