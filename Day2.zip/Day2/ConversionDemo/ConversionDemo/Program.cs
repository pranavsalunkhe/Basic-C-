﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConversionDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            //Implicit conversions - whenever we try to convert smaller data type to larger data type, so there is no data loss

            int i = 100;
            float f = i; // we dont need to cast data type
            Console.WriteLine(f);

            //Explicit conversions - we need to convert them explicitly - whenever we try to larger data type to smaller data type, so there is data loss

            float f2 = 212.66f;
            int j =(int) f2;
            //int j = Convert.ToInt32(f2); this is also valid
            Console.WriteLine(j);

            //Implicit conversion from child to parent is possible but vice versa, we need to do explicit casting for that using 'is' and 'as' keyword
            // 'is' is used to check whether given type is object or not, if it is object we need to cast is as a type using 'as' keyword, see below example

            //if (obj is Employee)
            //{
            //    Employee emp = obj as Employee;
            //}

            Console.ReadLine();
        }
    }
}
