﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArrayDemo
{
    //Arrays are fixed length data structure and ref type
    //when we have collection of data - array could be ref type and value type as well
    //All arrays have parent class as 'ARRAY'
    class Program
    {
        static void Main(string[] args)
        {
            //One Dimensional Array
            int[] intArray = { 1, 2, 3 }; //index starts with zero 

            for (int i = 0; i < intArray.Length; i++)
            {
                Console.WriteLine("Array Items: " + intArray[i]);
            }

            string[] strArray = new string[2];
            strArray[0] = "ABC";
            strArray[1] = "PQR";

            Array.Sort(strArray);   //for sorting

            foreach (string item in strArray)
            {
                Console.WriteLine(item);
            }

            //Two dimensional arrays

            int[,] Marks = new int[2, 3];

            Marks[0, 0] = 900;
            Marks[0, 1] = 800;
            Marks[0, 2] = 700;

            Marks[1, 0] = 600;
            Marks[1, 1] = 500;
            Marks[1, 2] = 200;

            for (int j = 0; j < Marks.GetLength(0); j++)
            {
                for (int k = 0; k < Marks.GetLength(1); k++)
                {
                    Console.WriteLine(Marks[j, k]);
                }
            }

            //Jagged Array - Array of Array - every element acts as an Array

            Console.ReadLine();
        }
    }
}
