﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BoxingUnboxingDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            //UnBoxing: converting ref type to value types - explicit casting

            object obj = 100;
            int i = (int)obj;

            Console.WriteLine(i);

            //Boxing: converting value type to ref type - implicit casting

            int j = 100;
            object obj1 = j;
            Console.WriteLine(obj1);

            Console.ReadLine();
        }
    }
}
