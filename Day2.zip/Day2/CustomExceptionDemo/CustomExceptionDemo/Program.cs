﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustomExceptionDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                EvenNumberProcessing();
            }
            catch (OddNumberException ex)
            {
                Console.WriteLine(ex.Message);
            }
            
            Console.ReadLine();
        }

        static void EvenNumberProcessing()
        {
            Console.WriteLine("Enter Even Number");
            string strEvenNumber = Console.ReadLine();
            int intEvenNumber = int.Parse(strEvenNumber);

            if (intEvenNumber % 2 != 0)
            {
                throw new OddNumberException("Enter correct even number...");
            }
            else
            {
                Console.WriteLine(intEvenNumber+" is Even Number");
            }
        }
    }
}
