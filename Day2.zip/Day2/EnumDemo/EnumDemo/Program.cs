﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EnumDemo
{
    // Enums are constant numerics

    enum EmpStatus {Permanent, Temporary, Consultant, Trainee};
    enum EmpGender {Male, Female};
    //enum EmpStatus { Permanent = 1, Temporary, Consultant = 7, Trainee }; we can specify our own index as well

    class Person
    {
        public string Name;
        //public int Status; //Permanent = 0, Temporary = 1, Consultant = 2, Trainee = 3
        public EmpStatus Status;
        public EmpGender Gender; // Male = 0; Female = 1;
    }
    class Program
    {        
        static void Main(string[] args)
        {
            Person per = new Person() { Name ="Pranav", Status = EmpStatus.Permanent, Gender = EmpGender.Male };

            Console.WriteLine("Employee Name is "+per.Name+" and Job Status is "+per.Status+" and Gender is "+per.Gender);

            int iStatus =(int) per.Status;
            Console.WriteLine(iStatus);

            Console.ReadLine();
        }
    }
}
