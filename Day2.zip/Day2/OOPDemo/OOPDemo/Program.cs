﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOPDemo
{
    class Item
    {
        public string ItemName;
        int ItemId;

        //Overloaded constructors: same name with different input parameters passed.
        public Item() //Parameterless constructor
        {
            Console.WriteLine("Parameterless constructor is called");
        }

        public Item(string ItemName, int ItemId)
        {
            this.ItemName = ItemName;
            this.ItemId = ItemId;
        }

        public int getItemId()
        {
            return ItemId;
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Item item = new Item("Mouse", 100);

            Console.ReadLine();
        }
    }    
}
