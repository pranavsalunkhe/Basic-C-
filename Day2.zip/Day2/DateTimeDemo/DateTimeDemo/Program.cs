﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DateTimeDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            DateTime dateTime1 = new DateTime(2019, 10, 12);
            Console.WriteLine(dateTime1);

            DateTime dateTime2 = DateTime.Now;
            Console.WriteLine(dateTime2);
            Console.WriteLine(dateTime2.Month);
            Console.WriteLine(dateTime2.Year);
            Console.WriteLine(dateTime2.Day);
            Console.WriteLine(dateTime2.DayOfWeek);

            DateTime dateTime3 = DateTime.Now.AddMonths(1);
            Console.WriteLine(dateTime3);

            string strDate = "10/12/2019";
            DateTime dateTime4 = DateTime.Parse(strDate);   //we have different format like tryparse, datetime.parse etc
            Console.WriteLine(dateTime4);

            //TimeSpan class is use to calulate difference between two dates

            DateTime d1 = new DateTime(2019, 10, 12);
            DateTime d2 = new DateTime(2019, 4, 7);

            TimeSpan span = d1 - d2;

            Console.WriteLine(span);         

            Console.ReadLine();
        }
    }
}
