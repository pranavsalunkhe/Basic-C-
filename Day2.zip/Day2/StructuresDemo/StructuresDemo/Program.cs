﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StructuresDemo
{
    //Difference between class and structs - 
    // Structs can not have parameterless constructors - by default it has parameterless constructor, only thing is that we can not write our own parameterless constructor.
    // Structs are value types whereas classes are ref types, hence structs are faster than classes
    // Structs can not have inheritance, but they can implement the interfaces
    struct Book
    {
        public string BookName;
        public int NoOfPages;

        public Book(string name, int page)
        {
            BookName = name;
            NoOfPages = page;
        }

        public void Readbook()
        {
            Console.WriteLine("Readbook is called");
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Book book = new Book("C#", 100);
            book.Readbook();

            Console.ReadLine();
        }
    }
}
