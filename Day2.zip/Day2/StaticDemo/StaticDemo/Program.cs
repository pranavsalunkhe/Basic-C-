﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


//static method can access only static members (fields, methods)
//non static method can call static as well as non static methods
//static members are accessed just by using class name (do not create instance of class)
//static member value shared accross all levels while instance veriable reinitiize each time
//static member will have all members are static only 

namespace StaticDemo
{
    class PerEmployee
    {
        public static int counter;
        public int counter1;

        public PerEmployee()
        {
            counter++;
            counter1++;
        }
        public static void getEmpStatus()
        {

        }
        public string EmpName;
        public void getSalary()
        {

        }
    }


    class Program
    {
        static void Main(string[] args)
        {
            //Method1(); //it shows error to create object
            Method2();

            Console.WriteLine(PerEmployee.counter); //access static member, dont need instance created
            PerEmployee.getEmpStatus();

            PerEmployee perEmployee = new PerEmployee();
            PerEmployee perEmployee1 = new PerEmployee();
            PerEmployee perEmployee2 = new PerEmployee();

            Console.WriteLine(perEmployee.counter1);            

            Console.WriteLine(perEmployee.EmpName);
            Console.ReadLine();
        }

        void Method1()
        {
            Method2();
        }

        static void Method2()
        {

        }
    }
}
