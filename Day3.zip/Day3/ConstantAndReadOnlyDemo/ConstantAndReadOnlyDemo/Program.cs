﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConstantAndReadOnlyDemo
{

    //global variable and local variables.

    //local variables declare in a method
    //global variable can be declare at a class level
    class A
    {
        //Constants value will be same throghout the scope of the variable
        //for constants variable we need to provide values at the time of declaration
        //Constant values are by default static
        //Constants can be declare as a globally and locally as well.
        public const float pi = 3.14f;  //global declaration

        //readonly variable - we may or may not initialize value at the time of declaration but we need to declare value only in constructor
        //readonly can be declared only at the class level.
        //readonly is not static, to access the value of readonly variable we need to instatntiate class
        public readonly int side;

        //Constructor
        public A()
        {
            side = 100;
        }

        public A(int _side)
        {
            _side = side;
        }

        public void Method1()
        {
            const float pi1 = 3.14f;    //local declaration

        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            A a = new A();
            A a1 = new A(200);
            
        }
    }
}
