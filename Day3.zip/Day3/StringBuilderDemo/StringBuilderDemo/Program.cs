﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StringBuilderDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            //Stringbuilder class

            //string is immutable reference type - create new reference each time, though we see single string, it will create 3 memory references.

            string list = "first"; //one ref
            list = list + "second";//second ref
            list = list + "third"; //third ref

            Console.WriteLine(list);

            //to avoid this we use stringbuilder class for string ops.

            StringBuilder stringBuilder = new StringBuilder("Pranav");

            stringBuilder.Append(" Jayavantrao");
            stringBuilder.Append(" Salunkhe");

            Console.WriteLine(stringBuilder);

            stringBuilder.Insert(0, "Mr. ");

            Console.WriteLine(stringBuilder);

            Console.ReadLine();
        }
    }
}
