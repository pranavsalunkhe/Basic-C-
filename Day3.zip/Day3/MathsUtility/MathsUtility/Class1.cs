﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MathsUtility
{
    public class MathsUtility
    {
        public void Add()
        {

        }

        private void Sub()
        {

        }

        protected void Mul()
        {

        }
        internal void Div()
        {

        }

        protected internal void Square()
        {

        }
    }
}
