﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MethodOverridingDemo
{

    class ConsultantEmp
    {
        public string Fname = "Pranav";
        public string Sname = " Salunkhe";

        public override string ToString()
        {
            return Fname + Sname;
        }

        public override bool Equals(object obj)
        {
            ConsultantEmp em = obj as ConsultantEmp;
            if (this.Fname == em.Fname)
            {
                return true;
            }
            else
                return false;
            //return base.Equals(obj);
        }
    }

    //Overriding is changing the actual behaviour--child is overriding the behaviour of parent class
    //Virtual is used with overriding
    //we can not have virtual methods as static and private
    class Vehicle
    {
        public int GetFuelDetails()         //This is called when child doesnt have method and we called it using child object
        {
            return 700;                 
        }

        //virtual keyword specifies that child class can override parents method
        public virtual void getEngineDetails()
        {

        }
    }

    class Car:Vehicle
    {
        //shadowing the behaviour of parent
        public new int GetFuelDetails() //added new to avoid warning 
        {                               //This is called when child does have method and we called it using child object and parent does have method as well.
            return 8000;                    
        }

        public override void getEngineDetails()
        {
            base.getEngineDetails();            //children is having their own implementation for this virtual method
        }

    }
    class Program
    {
        static void Main(string[] args)
        {
            string str1 = "hello world";
            string str2 = " hello world";

            Console.WriteLine(str1.Equals(str2));

            ConsultantEmp emp = new ConsultantEmp()  { Fname = "Pranav", Sname = " Salunkhe"};
            ConsultantEmp emp2 = new ConsultantEmp() { Fname = "Pranav", Sname = " Salunkhe"};

            Console.WriteLine(emp.Equals(emp2));

            Console.WriteLine(emp.ToString());

            Car car = new Car();

            Console.WriteLine("Fuel Capacity is: " + car.GetFuelDetails());
            Console.ReadLine();
        }
    }
}
