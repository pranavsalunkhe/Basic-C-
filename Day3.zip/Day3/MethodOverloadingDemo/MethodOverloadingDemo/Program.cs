﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MethodOverloadingDemo
{
    //Method Overloading: 
    //When method have same name but different parameters/return type of parameters passed
    //Overloaded method can have different access modifiers and return type as well
    class Product
    {
        protected void getProductDetails()
        {

        }

        protected void getProductDetails(int ProductID)
        {

        }

        protected void getProductDetails(float ProductID)
        {

        }

        protected void getProductDetails(float ProductID, string Name)
        {

        }

        public void getProductDetails(string Name)
        {

        }

        public int getProductDetails(double Name)
        {
            return 555;
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Product product = new Product();
            product.getProductDetails(45);

            //protected can not be called here as it works in inheritance hierarchy only


        }
    }
}
