﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractClassDemo
{
    //Abstract class: It can not be instantiated, they can be use in inheritance only
    //Abstract class will have abstract as well as non abstract methods
    //Abstract class is a contract that child classes should override the methods of parent class
    //Difference between virtual and abstract - Virtual can have their own implementation, but abstract dont, virtual method overriden is not mandatory but here it is mandatory
    
    abstract class Animal
    {
        abstract public void Run();
        abstract public void Eat();

        public void Method1()
        {

        }
    }

    class Dog : Animal
    {
        public override void Eat()
        {
            Console.WriteLine("Dogs can eat good food");
        }
        public override void Run()
        {
            Console.WriteLine("Dogs can run faster");
        }
    }

    class Puppy : Dog
    {
        public override void Eat()
        {
            base.Eat(); //we can comment this and write our own implementation
        }
        public override void Run()
        {
            base.Run();
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            //Animal animal = new Animal(); //gives error as abstract class can not be instantiated.
        }
    }
}
