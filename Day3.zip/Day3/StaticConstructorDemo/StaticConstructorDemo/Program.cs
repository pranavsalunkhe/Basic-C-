﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StaticConstructorDemo
{
    //static constructor always called once
    //1. When we instantiate class at the first time or
    //2. You access any static member of that class
    class Product
    {
        public static int productId;
        static string productName;

        static Product()
        {
            //static constructors are use to initialize static variables one time
            Console.WriteLine("Static constructor called...");
        }

    }
    class Program
    {
        static void Main(string[] args)
        {
            //Console.WriteLine(Product.productId);

            Product product = new Product();
            Product product2 = new Product();

            Console.ReadLine();
        }
    }
}
