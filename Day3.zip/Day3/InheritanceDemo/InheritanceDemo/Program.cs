﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MathsUtility;

namespace InheritanceDemo
{
    class Account
    {
        //protected members are available within inheritance hierarchy
        //public accessible everywhere
        //private is least permissible - members are default private: accessible within that class itself
        //Internal members available within an assembly or same namespace
        //Protected+internal - within that assembly and if other external class tries inheriting this class, it will work
        protected int AccountNumber { get; set; }
        public int BranchName { get; set; }

        public Account()
        {
            Console.WriteLine("Parent Constructor is called");
        }

        protected void GetPassBookDetails()
        {
            Console.WriteLine("Passbook detail is called");
        }
    }

    class SavingAccount : Account
    {
        public SavingAccount()
        {
            Console.WriteLine(AccountNumber + " " + BranchName);
            GetPassBookDetails();
            Console.WriteLine("Child Constructor is called");
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            SavingAccount savAccount = new SavingAccount();

            MathsUtility.MathsUtility mathsUtility = new MathsUtility.MathsUtility();
                        
            Console.ReadLine();
        }
    }
}
