﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SealedClassDemo
{

    sealed class ABC
    {

    }
    //class XYZ:ABC //it will give error but we can create instance of sealed class
    //{

    //}

    class House
    {
        public virtual void Slabs()
        {

        }
    }

    class RCCHouse : House
    {
        //public sealed override void Slabs()
        //{
        //    base.Slabs();
        //}

        public override void Slabs()
        {
            base.Slabs();
        }
    }

    class RCCChild : RCCHouse
    {
        public override void Slabs() //this will give error if we make above parent method as sealed
        {
            base.Slabs();
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            ABC abc = new ABC();
        }
    }
}
