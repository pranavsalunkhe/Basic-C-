﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PrivateConstructorDemo
{
    //class with private constructor is not instatiated
    //when we have class with only static members, private constructor will work
    class Employee
    {
        private Employee()
        {
            Console.WriteLine("Private constructor is called..");
        }

        public static void Method1()
        {

        }

        public Employee(string name, string address):this() //<---- using this we can call private constructor
        {
            Console.WriteLine(name + address);
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            //Employee emp = new Employee();  //private constructor will not allow us to instantiate class
            Employee emp = new Employee("Pranav", "Pune");

            Console.ReadLine();
        }
    }
}
