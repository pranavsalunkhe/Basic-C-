﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PropertiesDemo
{
    class Person
    {
        public string strFName; //field
        string strLName; //field

        //properties have getter and setter methods
        //type propfull and press tab to get automatic property and prop+tab for normal defination
        //We can just have getter only. They are primitive and non primitive as well.
        //properties can not be use as a ref or out parameter

        private int _Salary;    //proprties
        public int Salary
        {
            get
            {
                _Salary = GetSalary();
                return _Salary;
            }
            set
            {
                _Salary = value;
            }
        }

        private int GetSalary()
        {
            return 3000;
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Person person = new Person();
            Console.WriteLine(person.strFName);
            person.strFName = "Pranav";
            Console.WriteLine(person.strFName);

            Console.WriteLine(person.Salary);
            person.Salary = 15115;
            
            Console.WriteLine(person.Salary);

            Console.ReadLine();
        }
    }
}
