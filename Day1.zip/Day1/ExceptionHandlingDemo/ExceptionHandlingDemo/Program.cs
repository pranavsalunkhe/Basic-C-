﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExceptionHandlingDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            CallingMethod();   
            Console.ReadLine();
        }

        static void CallingMethod()
        {
            try
            {
                MethodDiv();
            }
            catch (FormatException ex)
            {
                Console.WriteLine(ex.Message + " Input data is not in correct format ");
            }
            
        }

        static void MethodDiv()
        {
            try
            {
                Console.WriteLine("Enter first number: ");
                string strFnum = Console.ReadLine();
                int intFnum = int.Parse(strFnum);
                //int.TryParse(strFnum, out intFnum);

                Console.WriteLine("Enter second number: ");
                string strSnum = Console.ReadLine();
                int intSnum = int.Parse(strSnum);
                //int.TryParse(strSnum, out intSnum);

                int intResult = intFnum / intSnum;

                Console.WriteLine("Result is : " + intResult);
            }
            catch (FormatException ex)
            {
                throw ex;
                //Console.WriteLine(ex.Message);  //we should write specific exceptions first and then generic exception at last
            }
            catch (DivideByZeroException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);  //all exception classes inherit from one parent class named as EXCEPTION
            }
            //Finally block gets executed in any condition
            finally
            {
                Console.WriteLine("Finally is executed");
            }            
        }
    }
}
