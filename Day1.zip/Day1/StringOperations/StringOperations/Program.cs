﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StringOperations
{
    class Program
    {
        static void Main(string[] args)
        {
            ////1. String Comparison

            //string str1 = "Hello World";
            //string str2 = "hello World"; // it will not work as C# is case sensitive

            //// == Operator

            //if (str1 == str2)
            //{
            //    Console.WriteLine("Strings are equal");
            //}
            //else
            //{
            //    Console.WriteLine("Strings are not equal");
            //}

            //4. Compare and CompareTo
            //CompareTo,
            //0, if both strings are equal
            //-1, if first string is small to that of second one
            //1, if first string is greater than second one

            //compare will do same operations and returns same result only difference is, it is the method of string class.

            //string str4 = "hello world";
            //string str5 = "hello world";

            //Console.WriteLine("Using CompareTo: "+str4.CompareTo(str5));
            //Console.WriteLine("Using Compare: "+String.Compare(str4,str5));

            //Console.WriteLine("Enter first Number");
            //int num1 = int.Parse(Console.ReadLine());
            ////int num1 = Convert.ToInt32(Console.ReadLine()); //another form of reading int values from the console

            ////int num1;
            ////int.TryParse(Console.ReadLine(), out num1);

            //// also we can use tryparse method to avoid exceptions

            //Console.WriteLine("Enter Second Number");
            //int num2 = int.Parse(Console.ReadLine());

            //int result = num1 / num2;

            //Console.WriteLine("Result is: " + result);

            ////2. Changing case of the string

            //Console.WriteLine(str2 + "Has been converted to Upper case as " + str2.ToUpper());
            //Console.WriteLine(str1 + "Has been converted to Lower case as " + str1.ToLower());

            ////Trim will remove blank spaces from the string, we have methods like, TrimEnd, TrimStart, Trim and Padding will add extra spaces.

            ////3. Trying multiple in built string operations using switch case

            //string str3 = string.Empty;
            //Console.WriteLine("Provide any string on which you want to perform any action");
            //str3 = Console.ReadLine();

            //switch (str3)
            //{
            //    case "abc":
            //        Console.WriteLine("The value you returned is " + str3);
            //        break;
            //    case "pqr":
            //        Console.WriteLine("The value you returned is " + str3);
            //        break;
            //    default:
            //        Console.WriteLine("Nothing returned");
            //        break;
            //}

            ////6. Convert to String
            //int price = 1000;
            //string strPrive = price.ToString(); //it will not throw any exceptions as any interger can be converted to string but vice versa is not true


            ////7. Padding
            //string strLangName = "Pranav";
            //Console.WriteLine("Before Padding "+strLangName);
            //strLangName = strLangName.PadLeft(10, '*');
            //Console.WriteLine("After Padding " + strLangName);

            ////8. Splitting
            //string names = " C#, Python, Java, Angular";
            //string[] arrName = names.Split(',');

            //Console.WriteLine("Items in Array : ");
            //foreach (string item in arrName)
            //{
            //    Console.WriteLine(item);
            //}

            //9. Join Strings
            string name1 = "C#";
            string name2 = "Java";
            string name3 = "Python";
            string name4 = "Angular";

            Console.WriteLine(string.Join(",", name1, name2, name3, name4));    

            Console.ReadLine();
        }
    }
}
