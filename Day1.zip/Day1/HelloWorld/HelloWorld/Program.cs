﻿using System;
using DataAccess;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//Each concole app will have one entry point
namespace HelloWorld
{
    class Program
    {
        //static void Main() - It will also work
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World");

            string EmpName = string.Empty;

            Console.WriteLine("Enter Your Name: ");
            EmpName = Console.ReadLine();

            Console.WriteLine("Welcome " + EmpName); //this will work
            Console.WriteLine("By using placeholder, Welcome {0}", EmpName); // this will also work

            //Readline is going to read complete line however read will read only single char but return integer value. Read char and convert it to the ASCII value
            //Ending the code
            Console.WriteLine("Press any key to exit...");
            Console.ReadLine();

            Product prd = new Product();
            Console.WriteLine(prd.ProductName);
            Console.WriteLine(prd.ProductId);

            Console.ReadLine();

        }
    }
    
}
