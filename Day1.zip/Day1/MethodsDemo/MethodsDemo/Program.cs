﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MethodsDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            //test1();
            //test2(100, 200);
            //Console.WriteLine("Result of function 3 is: "+test3(10, 20));
            //test4();

            test5(out int Result, out bool Status);
            Console.WriteLine(Result + " " + Status);

            test6("Pranav", 1, 2, 3, 4, 5, 6, 7, 8); // Params could have n numbers of arguments
            test6("Pranav"); // Params could have 0 arguments

            Console.ReadLine();
        }
        //pattern1
        static void test1()
        {
            Console.WriteLine("test1 is called"); //a give static method can call only static method
        }
        //pattern2
        static void test2(int num1, int num2)
        {
            Console.WriteLine("test2 is called"); //parameterised method
        }
        //pattern3
        static int test3(int num1, int num2)
        {
            return num1 + num2;      //parameterised method with int return type
        }
        //pattern4 method returning in between
        static void test4()
        {
            Console.WriteLine("Enter first number: ");
            string strNum1 = Console.ReadLine();
            int num1;
            int.TryParse(strNum1, out num1);

            if (num1 == 0)
            {
                return;
            }

            Console.WriteLine("Enter second number: ");
            string strNum2 = Console.ReadLine();
            int num2;
            int.TryParse(strNum1, out num2);

            int intResult = num1 / num2;

            Console.WriteLine(intResult);
        }

        //pattern5 with out parameters, if we want to return more than one value by our function , then use out parameter, it is good practice.
        static void test5(out int outResult, out Boolean boolStatus)
        {
            Console.WriteLine("Enter first number: ");
            string strNum1 = Console.ReadLine();
            int num1;
            int.TryParse(strNum1, out num1);           

            Console.WriteLine("Enter second number: ");
            string strNum2 = Console.ReadLine();
            int num2;
            int.TryParse(strNum1, out num2);

            outResult = num1 / num2;

            if (outResult > 5)
                boolStatus = true;            
            else
                boolStatus = false; 
            
            //Console.WriteLine(intResult);
        }

        //pattern6 with Params (varargs in Java)

        static void test6(string name, params int[] vars)
        {

        }

    }
}
