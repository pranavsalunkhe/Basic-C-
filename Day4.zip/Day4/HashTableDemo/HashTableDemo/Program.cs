﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HashTableDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            //key should be unique in hashtable
            Hashtable ht = new Hashtable();

            ht.Add("Key1", "C#");
            //ht.Add(1, "Java"); this will also work, but we need to type casting accordingly
            ht.Add("key2", "Python");
            ht.Add("key3", "Java");

            //there are two methods to iterate over Hash table
            //using dictionaryentry
            foreach (DictionaryEntry entry in ht)
            {
                Console.WriteLine(entry.Key + " " + entry.Value);
            }

            //we cannot search item using index like array list, we have to search item/value by passing key
            Console.WriteLine("Enter key to be searched: ");
            string strKey = Console.ReadLine();

            string strValue = ht[strKey].ToString();
            Console.WriteLine("Value associate with key " + strKey + " is " + strValue);

            //second way to iterate over hash table just like pointer
            IDictionaryEnumerator enumerator = ht.GetEnumerator();

            while (enumerator.MoveNext())
            {
                Console.WriteLine(enumerator.Key + " " + enumerator.Value);
            }

            Console.ReadLine();
        }
    }
}
