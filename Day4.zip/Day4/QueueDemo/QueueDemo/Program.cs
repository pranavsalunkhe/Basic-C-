﻿using System;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QueueDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            Queue queue = new Queue();

            queue.Enqueue(10);
            queue.Enqueue(20);
            queue.Enqueue(30); 
            queue.Enqueue(40);

            queue.Dequeue(); //Removes first element as it works on a principle for FIFO

            foreach (int i in queue)
            {
               Console.WriteLine(i);
            }

            Console.ReadLine();
        }
    }
}
