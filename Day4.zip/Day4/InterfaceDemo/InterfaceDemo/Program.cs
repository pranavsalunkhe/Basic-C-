﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InterfaceDemo
{
    //Interface are like contract what our methods, properties, event and indexers should be there, we can not declare variables
    //It will not have any definition, it will just have declaration
    //By default all members are public, we can not have any other access modifiers
    interface IDataAccess
    {
        string ReadData(string connectionName);
        void WriteData(string connectionName);

        string DataConnection { get; set; }
    }

    class FileAccess : IDataAccess
    {
        public string DataConnection { get; set; }

        public string ReadData(string connectionName)
        {
            //throw new NotImplementedException();
            Console.WriteLine("Reading Data through file server");
            return "file Data";
        }

        public void WriteData(string connectionName)
        {
            //throw new NotImplementedException();
            Console.WriteLine("Writing Data to file server");
        }
    }

    class SQLDataAccess : IDataAccess
    {
        public string DataConnection { get; set; }
        

        public string ReadData(string connectionName)
        {
            //throw new NotImplementedException();
            Console.WriteLine("Reading Data through SQL server");
            return "SQL Data";
        }

        public void WriteData(string connectionName)
        {
            //throw new NotImplementedException();
            Console.WriteLine("Writing Data to SQL server");
        }
    }

    class Program
    {
     
        static void Main(string[] args)
        {
            SQLDataAccess dataAccess = new SQLDataAccess();
            dataAccess.DataConnection = "sql";
            SaveData(dataAccess);

            FileAccess fileAccess = new FileAccess();
            dataAccess.DataConnection = "filename";
            SaveData(fileAccess);


            //DataAccess dataAccess1 = new SQLDataAccess(); //this is also possible. we can cast to interface as well

            //dataAccess.ReadData("SQL");
            //dataAccess.WriteData("sql");

            Console.ReadLine();
        }

        static void SaveData(IDataAccess data)
        {
            data.ReadData(data.DataConnection);
            data.WriteData(data.DataConnection);
        }
    }
}

//difference between abstract classes and interfaces

    /*
     * Class can implement multiple interfaces, but abstract classes we have only one abstract classes
     * abstract class can have abstract and non abstract methods but interface could have methods that should be implemented by class for sure
     * we can not inherit more than one abstract class but a class can implement multiple interfaces
     * By using interfaces, we can achieve multiple inheritance in C#
     * abstract class can have constructor whereas interfaces doesn't have constructors
     * abstract classes can have static members whereas interfaces would not have any static members
     * interfaces should have all members as public and same is the case with abstract classes, but in abstract class we can have other methods as non public
     * performance of abstract class is faster than interfaces because interface could take time to search actual methods 
     * 
     */