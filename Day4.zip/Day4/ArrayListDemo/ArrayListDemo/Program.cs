﻿using System;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArrayListDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            ArrayList list = new ArrayList();

            string option = string.Empty;
            do
            {
                Console.Write("Add Member to the list: ");
                string value = Console.ReadLine();

                list.Add(value);

                Console.Write("Do you want to continue, press yes/no: ");
                option = Console.ReadLine();

            } while (option == "yes");

            Console.WriteLine("Items in a list ");

            foreach (string s in list)
            {
                Console.WriteLine(s);
            }

            Console.ReadLine();
        }
    }
}
