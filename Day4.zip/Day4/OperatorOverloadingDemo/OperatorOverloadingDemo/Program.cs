﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OperatorOverloadingDemo
{
    class Calculator
    {
        public int number1;
        public int number2;

        public Calculator()
        {

        }

        public Calculator(int number1, int number2)
        {
            this.number1 = number1;
            this.number2 = number2;
        }

        public static Calculator operator +(Calculator cal) // for binary we have to just pass two parameters
        {
            Calculator objcal = new Calculator();

            objcal.number1 = cal.number1 + 1; // and for binary we can add two  values
            objcal.number2 = cal.number2 + 1;

            return objcal;
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Calculator cal1 = new Calculator(10, 20);
            Calculator cal2 = new Calculator(50, 20);

            cal1 = +cal1;//11,21

            Console.WriteLine(cal1.number1 + " " +cal1.number2);

            //Opearators: +,-,<,>,<<,>>
            //Unary Operator (Operates on single operand)
            //int i = 100;
            //i = +i;
            //Console.WriteLine(i);

            Console.ReadLine();
        }
    }
}
