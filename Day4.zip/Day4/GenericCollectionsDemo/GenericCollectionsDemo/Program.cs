﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GenericCollectionsDemo
{
    class Employee
    {
        public int id;
        public string name;

        public Employee(int id, string name)
        {
            this.id = id;
            this.name = name;
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            //Generic collection - having <> symbol
            //Generic collection doesn't required type casting
            //Faster than non generic

            List<string> list1 = new List<string>();

            list1.Add("C#");
            list1.Add("Java");
            //list1.Add(1); //this will throw compile time error

            foreach (string data in list1)
            {
                Console.WriteLine(data);
            }

            Employee emp = new Employee(1, "Pranav");
            Employee emp2 = new Employee(2, "ABC");
            Employee emp3 = new Employee(3, "XYZ");

            List<Employee> empList = new List<Employee>();

            empList.Add(emp);
            // empList.Add("Strkm"); //this will throw compile time error
            empList.Add(emp2);
            empList.Add(emp3);

            foreach(Employee emp5 in empList)
            {
                Console.WriteLine(emp5.id+" "+emp5.name);

            }
            Console.ReadLine();

        }
    }
}
