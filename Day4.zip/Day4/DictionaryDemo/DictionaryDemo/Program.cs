﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DictionaryDemo
{

    class Employee
    {
        public int id;
        public string name;

        public Employee(int id, string name)
        {
            this.id = id;
            this.name = name;
        }
    }


    //Generic version of hashtable is Dictionary<> like List<> is generic version of ArrayList
    //Generic implementation of stack and queue is also available like Stack<> and Queue<>
    class Program
    {
        static void Main(string[] args)
        {

            Dictionary<string, Employee> emps = new Dictionary<string, Employee>();

            Employee emp1 = new Employee(100, "Pranav");
            Employee emp2 = new Employee(200, "Sonu");

            emps.Add("1", emp1);
            emps.Add("2", emp2);

            IDictionaryEnumerator enumerator = emps.GetEnumerator();
            while (enumerator.MoveNext())
            {
                //Console.WriteLine(enumerator.Key);
                Employee emp = emps[enumerator.Key.ToString()];
                Console.WriteLine(enumerator.Key + " "+emp.id + " " + emp.name);

            }

            Console.ReadLine();
        }
    }

    
}
