﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StackDemo
{
    class Program
    {
        //all collections will have method Contain only Hashtable has ContainsKey and ContainsValue methods
        //all collections return Object
        static void Main(string[] args)
        {
            Stack st = new Stack();
            st.Push(10);
            st.Push(11);
            st.Push(12);
            st.Push(13);

            st.Pop(); //removes last element as it works on a principle of LIFO (Last In First Out)

            foreach (int i in st)
            {
                Console.WriteLine(i);
            }

            Console.ReadLine();
        }
    }
}
