﻿using System;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CollectionsDemo
{

    class Employee
    {
        public int EmployeeId { get; set; }
        public string EmployeeNm { get; set; }
    }

    class Program
    {
        static void Main(string[] args)
        {
            //Array
            int[] array = new int[2] { 1, 2 };

            //ArrayList
            ArrayList list = new ArrayList();
            list.Add("C#");
            list.Add("Java");
            list.Add("Python");

            for (int i = 0; i<list.Count;i++)
            {
                string name = list[i].ToString();

                Console.WriteLine(name);
            }

            foreach (Object ob in list)
            {
                Console.WriteLine(ob.ToString());
            }

            Employee emp1 = new Employee() { EmployeeId = 100, EmployeeNm = "Pranav" };
            Employee emp2 = new Employee() { EmployeeId = 200, EmployeeNm = "Sonu" };

            ArrayList empList = new ArrayList();
            empList.Add(emp1);
            empList.Add(emp2);
            empList.Add("xyz"); //if we add other data type follow below for loop, we need to typecast

            for (int j = 0; j < empList.Count; j++)
            {
                if (j == 2)
                {
                    int num = (int) empList[j];
                    Console.WriteLine(num);
                }
                else
                {
                    Employee emp3 = empList[j] as Employee;
                    Console.WriteLine(emp3.EmployeeId + " " + emp3.EmployeeNm);
                }
                    
            }

            if (empList.Contains(2))
            {
                Console.WriteLine("List contains 2");
            }
            empList.Remove(2);
            empList.RemoveAt(0);

            //foreach (Employee emp in empList)               //for retrieving same data
            //{
            //    Console.WriteLine(emp.EmployeeId + " " + emp.EmployeeNm);
            //}

            Console.ReadLine();
        }
    }
}
