﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MiscDemo
{
    class Program
    {
        //Partial class = one class, but functionality distributed in different files so that multiple developer would work on same class
        //Use Partial keyword

        //Var keyword = type inference
        //When we are not sure about return type, then we need to use var keyword
        static void Main(string[] args)
        {
            var ddd = "Pranav"; //It will act as a string 
            var sss = 454654; //It will act as integer

            //to sort reference type we need to implement IComparable interface
            
        }
    }
}
