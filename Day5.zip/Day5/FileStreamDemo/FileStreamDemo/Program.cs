﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace FileStreamDemo
{
    class Program
    {
        static void Main(string[] args)
        {

            try
            {
                using (FileStream stream = new FileStream("C:\\temp\\yyy.txt", FileMode.Create))
                {
                    using (StreamWriter writer = new StreamWriter(stream))
                    {
                        string option = string.Empty;

                        do
                        {
                            Console.WriteLine("Enter Employee Name to be added in file");
                            string details = Console.ReadLine();

                            writer.WriteLine(details);

                            Console.WriteLine("Do you want to continue: yes/no");
                            option = Console.ReadLine();
                        }

                        while (option == "yes");

                    }
                }

                //writer.WriteLine("Employee Details are....");
                //writer.WriteLine("Employee Name : Pranav");
                //writer.WriteLine("Employee ID : 021072");
                //writer.WriteLine("Employee Address : Pune");
                //writer.WriteLine("Employee Mob No. : 8483088112");

                //writer.Close();
                //stream.Close();   //commented this when we start using

            }

            catch (Exception ex)
            { }

            
            
        }
    }
}
