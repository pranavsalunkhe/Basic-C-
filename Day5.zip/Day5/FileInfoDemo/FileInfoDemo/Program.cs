﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FileInfoDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                FileInfo info = new FileInfo("C:\\temp\\zzz.txt");

                if (!info.Exists)
                {
                    info.Create();
                }

                info.CopyTo("C:\\temp\\yyy.txt");
                                                                                                      
            }

            catch (Exception ex)
            {

            }

            

        }
    }
}
