﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BinaryDemo
{
    class Program
    {
        //There are more classes like GetDirectoryInfo, GetDriverInfo, GetFileInfo
        static void Main(string[] args)
        {
            //FileStream stream = null;
            //BinaryWriter writer = null;
            //try
            //{
            //    stream = new FileStream("C:\\Temp\\emp1.bin", FileMode.Create);

            //    writer = new BinaryWriter(stream);

            //    writer.Write(true);
            //    writer.Write("Pranav");
            //    writer.Write(1234);
            //    writer.Write(12.35);

            //}

            //catch (Exception ex)
            //{
            //}

            //finally
            //{
            //    writer.Close();
            //    stream.Close();

            //}           

            ReadBinaryData();

        }

        static void ReadBinaryData()
        {
            FileStream fs = null;
            BinaryReader reader = null;
            try
            {
                fs = new FileStream("C:\\Temp\\emp1.bin", FileMode.Open);
                reader = new BinaryReader(fs);

                bool b1 = reader.ReadBoolean();
                string name = reader.ReadString();
                int num = reader.ReadInt32();

                Console.WriteLine(b1 + " " + name + " " + num);
            }

            catch (Exception ex)
            {
            }

            finally
            {
                reader.Close();
                fs.Close();

            }

            Console.ReadLine();


        }
    }
}
