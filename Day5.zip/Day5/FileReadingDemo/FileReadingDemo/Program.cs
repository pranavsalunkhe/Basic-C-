﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FileReadingDemo
{
    class Employee
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string City { get; set; }
    }
    class Program
    {
        static void Main(string[] args)
        {
            List<Employee> emps = new List<Employee>();
            using (FileStream stream = new FileStream("C:\\temp\\Employee.txt",FileMode.Open))
            {
                using (StreamReader reader = new StreamReader(stream))
                {
                    while (!reader.EndOfStream)
                    {
                        Employee emp = new Employee();
                        string line = reader.ReadLine();
                        string[] array1 = line.Split(',');

                        emp.Id = int.Parse(array1[0]);
                        emp.Name = array1[1];
                        emp.City = array1[2];

                        emps.Add(emp);

                        //Console.WriteLine(line);
                    }
                }
            }
            Console.ReadLine();
        }
    }
}
