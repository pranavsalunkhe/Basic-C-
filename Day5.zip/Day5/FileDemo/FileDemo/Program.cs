﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


//File - For basic operations - this class is static
//FileInfo
//FileStream
namespace FileDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {/*
                if (!File.Exists("C:\\temp\\abc.txt"))
                {
                    File.Create("C:\\temp\\abc.txt");
                }
                else
                    Console.WriteLine("File already exist...");*/

                List<string> list = new List<string>();
                list.Add("Pranav");
                list.Add("Salunkhe");

                File.AppendAllLines("C:\\temp\\xyz.txt",list); //second parameter is of type IEnumerable

                string data = "This data will be written to pqr file..";
                File.WriteAllText("C:\\temp\\pqr.txt", data);

                string[] str = new string[] { "Amar", "Akbar", "Anthony" };
                File.WriteAllLines("C:\\temp\\lmn.txt", str);

                File.Copy("C:\\temp\\lmn.txt", "C:\\temp\\zzz.txt");
                
            }
            catch (Exception ex)
            {

            }

            Console.ReadLine();

        }
    }
}
