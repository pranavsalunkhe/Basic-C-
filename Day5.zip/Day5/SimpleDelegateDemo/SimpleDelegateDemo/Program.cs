﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//This code is not complete, please consider the code from CLG from Mukta

namespace SimpleDelegateDemo
{

    delegate void SimpleDelegate(int x, int y);
    delegate void PromotionDelegate();

    class Employee
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int Experience { get; set; }
    }

    class Program
    {
        //Delegate: Just a pointer to a method
        //We can pass method as a parameter using Delegate
        //Using Delegate at a time we can call more than one methods only
        //We can declare delegate as local or global variable

        //delegate void SimpleDelegate(int x, int y); // This is also fine
        static void Main(string[] args)
        {
            //SimpleDelegate simple = new SimpleDelegate(Add);
            //simple(10, 20);
            //simple.Invoke(10, 20);//This is also correct syntax

            PromotionDelegate dlg = new PromotionDelegate();

            List<Employee> emps = new List<Employee>();

            emps.Add(new Employee() { Id = 1, Name = "Pranav", Experience = 1 });
            emps.Add(new Employee() { Id = 2, Name = "Ashish", Experience = 3 });

            Console.ReadLine();
        }

        static void DoPromotion(List<Employee> empList, PromotionDelegate())
        {
            foreach (Employee empss in empList)
            {

            }
            DoPromotionBySalary();
        }

        private static void DoPromotionBySalary()
        {
            Console.WriteLine("DoPromotionBySalary called...");
        }

        private static void DoPromotionByExperience()
        {
            Console.WriteLine("DoPromotionByExperience called...");
        }

        static void Add(int a, int b)
        {
            Console.WriteLine("Add is called");
        }        
    }
}
